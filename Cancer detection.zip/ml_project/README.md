# 🧠 ML Cancer Detection Classifier

A full end-to-end machine learning project for binary classification using the
**Wisconsin Breast Cancer Dataset** (built into scikit-learn — no downloads needed).

## 📁 Project Structure

```
ml_project/
├── README.md
├── requirements.txt
├── main.py                  ← Run this!
├── src/
│   ├── data_loader.py       ← Load & split data
│   ├── eda.py               ← Exploratory Data Analysis + plots
│   ├── preprocessing.py     ← Scaling & feature selection
│   ├── models.py            ← Train 5 ML models + hyperparameter tuning
│   └── evaluation.py        ← Metrics, confusion matrix, ROC curve
└── outputs/                 ← All plots and saved model land here
```

## 🚀 Quick Start

### 1. Install dependencies
```bash
pip install -r requirements.txt
```

### 2. Run the full pipeline
```bash
python main.py
```

That's it! The script will:
- Load and explore the dataset
- Preprocess features
- Train & tune 5 models: Logistic Regression, Random Forest, SVM, KNN, XGBoost
- Print a full evaluation report
- Save all plots to `outputs/`
- Save the best model to `outputs/best_model.pkl`

## 📊 What You'll See

| Step | Output |
|------|--------|
| EDA | Class distribution, feature correlation heatmap, boxplots |
| Training | Accuracy of each model with cross-validation |
| Tuning | Grid search for best hyperparameters |
| Evaluation | Confusion matrix, ROC curve, precision-recall curve |
| Report | Classification report with precision, recall, F1 |

## 🧪 Dataset

**Wisconsin Breast Cancer Dataset**
- 569 samples, 30 features
- Binary target: Malignant (0) / Benign (1)
- Source: `sklearn.datasets.load_breast_cancer()`

## 🛠️ Requirements

- Python 3.8+
- See `requirements.txt` for packages
