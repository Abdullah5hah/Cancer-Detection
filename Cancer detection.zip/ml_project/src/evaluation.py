"""
evaluation.py
-------------
Full evaluation suite:
  - Classification report (precision, recall, F1, support)
  - Confusion matrix (heatmap)
  - ROC curves for all models
  - Precision-Recall curves for all models
  - Feature importance (Random Forest / XGBoost)
"""

import os
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import (
    classification_report,
    confusion_matrix,
    roc_curve, auc,
    precision_recall_curve, average_precision_score,
)


CLASS_NAMES = ["Malignant", "Benign"]
COLORS = plt.cm.tab10.colors


# ── Text report ──────────────────────────────────────────────────────────────

def print_report(model, X_test, y_test, model_name: str = "Best Model"):
    y_pred = model.predict(X_test)
    acc = (y_pred == y_test).mean()
    print("=" * 58)
    print(f"  📋 Classification Report — {model_name}")
    print("=" * 58)
    print(f"  Test Accuracy : {acc:.4f}  ({acc*100:.2f}%)\n")
    print(classification_report(y_test, y_pred, target_names=CLASS_NAMES))


# ── Confusion matrix ─────────────────────────────────────────────────────────

def plot_confusion_matrix(model, X_test, y_test,
                          model_name: str, output_dir: str):
    y_pred = model.predict(X_test)
    cm = confusion_matrix(y_test, y_pred)

    fig, ax = plt.subplots(figsize=(6, 5))
    sns.heatmap(cm, annot=True, fmt="d", cmap="Blues",
                xticklabels=CLASS_NAMES, yticklabels=CLASS_NAMES,
                linewidths=1, linecolor="white", ax=ax,
                annot_kws={"size": 14, "fontweight": "bold"})
    ax.set_xlabel("Predicted Label", fontsize=12)
    ax.set_ylabel("True Label", fontsize=12)
    ax.set_title(f"Confusion Matrix — {model_name}", fontsize=13, fontweight="bold")

    plt.tight_layout()
    path = os.path.join(output_dir, "5_confusion_matrix.png")
    plt.savefig(path, dpi=150)
    plt.close()
    print(f"   Confusion matrix saved → {path}")


# ── ROC curves ───────────────────────────────────────────────────────────────

def plot_roc_curves(fitted_models: dict, X_test, y_test, output_dir: str):
    fig, ax = plt.subplots(figsize=(8, 6))

    for idx, (name, model) in enumerate(fitted_models.items()):
        if hasattr(model, "predict_proba"):
            proba = model.predict_proba(X_test)[:, 1]
        elif hasattr(model, "decision_function"):
            proba = model.decision_function(X_test)
        else:
            continue

        fpr, tpr, _ = roc_curve(y_test, proba)
        roc_auc = auc(fpr, tpr)
        ax.plot(fpr, tpr, color=COLORS[idx % len(COLORS)],
                lw=2, label=f"{name}  (AUC = {roc_auc:.3f})")

    ax.plot([0, 1], [0, 1], "k--", lw=1, label="Random Classifier")
    ax.set_xlim([0.0, 1.0])
    ax.set_ylim([0.0, 1.05])
    ax.set_xlabel("False Positive Rate", fontsize=12)
    ax.set_ylabel("True Positive Rate", fontsize=12)
    ax.set_title("ROC Curves — All Models", fontsize=13, fontweight="bold")
    ax.legend(loc="lower right", fontsize=10)
    ax.grid(True, alpha=0.3)

    plt.tight_layout()
    path = os.path.join(output_dir, "6_roc_curves.png")
    plt.savefig(path, dpi=150)
    plt.close()
    print(f"   ROC curves saved       → {path}")


# ── Precision-Recall curves ──────────────────────────────────────────────────

def plot_pr_curves(fitted_models: dict, X_test, y_test, output_dir: str):
    fig, ax = plt.subplots(figsize=(8, 6))

    for idx, (name, model) in enumerate(fitted_models.items()):
        if hasattr(model, "predict_proba"):
            proba = model.predict_proba(X_test)[:, 1]
        elif hasattr(model, "decision_function"):
            proba = model.decision_function(X_test)
        else:
            continue

        precision, recall, _ = precision_recall_curve(y_test, proba)
        ap = average_precision_score(y_test, proba)
        ax.plot(recall, precision, color=COLORS[idx % len(COLORS)],
                lw=2, label=f"{name}  (AP = {ap:.3f})")

    ax.set_xlabel("Recall", fontsize=12)
    ax.set_ylabel("Precision", fontsize=12)
    ax.set_title("Precision-Recall Curves — All Models", fontsize=13, fontweight="bold")
    ax.legend(loc="lower left", fontsize=10)
    ax.grid(True, alpha=0.3)

    plt.tight_layout()
    path = os.path.join(output_dir, "7_pr_curves.png")
    plt.savefig(path, dpi=150)
    plt.close()
    print(f"   PR curves saved        → {path}")


# ── Feature importance ───────────────────────────────────────────────────────

def plot_feature_importance(fitted_models: dict, feature_names: list,
                             output_dir: str, top_n: int = 15):
    """Plot feature importance for tree-based models."""
    tree_models = {k: v for k, v in fitted_models.items()
                   if hasattr(v, "feature_importances_")}

    if not tree_models:
        return

    n = len(tree_models)
    fig, axes = plt.subplots(1, n, figsize=(8 * n, 6))
    if n == 1:
        axes = [axes]

    for ax, (name, model) in zip(axes, tree_models.items()):
        importances = model.feature_importances_
        indices = np.argsort(importances)[::-1][:top_n]
        feat_labels = [feature_names[i] for i in indices]

        ax.barh(range(top_n), importances[indices][::-1],
                color=plt.cm.viridis(np.linspace(0.3, 0.9, top_n)))
        ax.set_yticks(range(top_n))
        ax.set_yticklabels(feat_labels[::-1], fontsize=9)
        ax.set_title(f"Feature Importance — {name}", fontsize=12, fontweight="bold")
        ax.set_xlabel("Importance Score")
        ax.grid(True, axis="x", alpha=0.3)

    plt.tight_layout()
    path = os.path.join(output_dir, "8_feature_importance.png")
    plt.savefig(path, dpi=150)
    plt.close()
    print(f"   Feature importance     → {path}")
