"""
data_loader.py
--------------
Loads the Breast Cancer dataset and splits it into train/test sets.
"""

import pandas as pd
from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split


def load_data(test_size: float = 0.2, random_state: int = 42):
    """
    Load the Wisconsin Breast Cancer dataset and return train/test splits.

    Returns
    -------
    X_train, X_test, y_train, y_test : numpy arrays
    feature_names                     : list[str]
    df                                : full DataFrame (for EDA)
    """
    raw = load_breast_cancer()

    df = pd.DataFrame(raw.data, columns=raw.feature_names)
    df["target"] = raw.target
    df["diagnosis"] = df["target"].map({0: "Malignant", 1: "Benign"})

    X = raw.data
    y = raw.target

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=test_size, random_state=random_state, stratify=y
    )

    print(f"✅ Dataset loaded: {X.shape[0]} samples, {X.shape[1]} features")
    print(f"   Train: {X_train.shape[0]} | Test: {X_test.shape[0]}")
    print(f"   Classes: {dict(zip(raw.target_names, [sum(y==0), sum(y==1)]))}\n")

    return X_train, X_test, y_train, y_test, list(raw.feature_names), df
