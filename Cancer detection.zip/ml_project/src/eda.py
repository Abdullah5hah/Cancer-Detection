"""
eda.py
------
Exploratory Data Analysis: class distribution, correlation heatmap,
feature boxplots, and pairplot of top features.
"""

import os
import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd


def run_eda(df: pd.DataFrame, output_dir: str = "outputs"):
    os.makedirs(output_dir, exist_ok=True)
    print("📊 Running Exploratory Data Analysis...")

    _plot_class_distribution(df, output_dir)
    _plot_correlation_heatmap(df, output_dir)
    _plot_feature_boxplots(df, output_dir)
    _plot_pairplot(df, output_dir)

    print(f"   Plots saved to '{output_dir}/'\n")


# ── helpers ──────────────────────────────────────────────────────────────────

def _plot_class_distribution(df, output_dir):
    fig, axes = plt.subplots(1, 2, figsize=(10, 4))
    fig.suptitle("Class Distribution", fontsize=14, fontweight="bold")

    counts = df["diagnosis"].value_counts()
    colors = ["#E74C3C", "#2ECC71"]

    axes[0].bar(counts.index, counts.values, color=colors, edgecolor="white", width=0.5)
    axes[0].set_title("Count")
    axes[0].set_ylabel("Number of Samples")
    for i, v in enumerate(counts.values):
        axes[0].text(i, v + 3, str(v), ha="center", fontweight="bold")

    axes[1].pie(counts.values, labels=counts.index, autopct="%1.1f%%",
                colors=colors, startangle=90,
                wedgeprops={"edgecolor": "white", "linewidth": 2})
    axes[1].set_title("Proportion")

    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, "1_class_distribution.png"), dpi=150)
    plt.close()


def _plot_correlation_heatmap(df, output_dir):
    numeric_df = df.drop(columns=["target", "diagnosis"])
    # Use only the first 15 features for readability
    corr = numeric_df.iloc[:, :15].corr()

    fig, ax = plt.subplots(figsize=(14, 10))
    sns.heatmap(corr, annot=True, fmt=".2f", cmap="coolwarm",
                center=0, linewidths=0.5, ax=ax,
                annot_kws={"size": 7})
    ax.set_title("Feature Correlation Heatmap (top 15 features)", fontsize=14, fontweight="bold")
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, "2_correlation_heatmap.png"), dpi=150)
    plt.close()


def _plot_feature_boxplots(df, output_dir):
    top_features = [
        "mean radius", "mean texture", "mean perimeter",
        "mean area", "mean smoothness", "mean compactness"
    ]
    fig, axes = plt.subplots(2, 3, figsize=(14, 8))
    fig.suptitle("Feature Distributions by Diagnosis", fontsize=14, fontweight="bold")

    for ax, feat in zip(axes.flat, top_features):
        sns.boxplot(data=df, x="diagnosis", y=feat, ax=ax,
                    hue="diagnosis", legend=False,
                    palette={"Malignant": "#E74C3C", "Benign": "#2ECC71"})
        ax.set_title(feat.title())
        ax.set_xlabel("")

    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, "3_feature_boxplots.png"), dpi=150)
    plt.close()


def _plot_pairplot(df, output_dir):
    top = ["mean radius", "mean texture", "mean area", "mean smoothness", "diagnosis"]
    subset = df[top].sample(200, random_state=42)  # sample for speed
    g = sns.pairplot(subset, hue="diagnosis",
                     palette={"Malignant": "#E74C3C", "Benign": "#2ECC71"},
                     plot_kws={"alpha": 0.6}, diag_kind="kde")
    g.figure.suptitle("Pairplot of Top Features (200 samples)", y=1.02,
                       fontsize=13, fontweight="bold")
    g.figure.savefig(os.path.join(output_dir, "4_pairplot.png"), dpi=120, bbox_inches="tight")
    plt.close()
