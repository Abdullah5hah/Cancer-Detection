"""
preprocessing.py
----------------
Standard scaling + optional PCA for dimensionality reduction.
Returns scaled arrays ready for model training.
"""

import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA


def preprocess(X_train, X_test, use_pca: bool = False, n_components: int = 15):
    """
    Scale features and optionally reduce dimensions with PCA.

    Parameters
    ----------
    X_train, X_test : numpy arrays
    use_pca         : apply PCA after scaling (default False)
    n_components    : number of PCA components if use_pca=True

    Returns
    -------
    X_train_proc, X_test_proc, scaler, (pca or None)
    """
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled  = scaler.transform(X_test)

    if use_pca:
        pca = PCA(n_components=n_components, random_state=42)
        X_train_proc = pca.fit_transform(X_train_scaled)
        X_test_proc  = pca.transform(X_test_scaled)
        explained = np.sum(pca.explained_variance_ratio_) * 100
        print(f"🔧 PCA applied: {n_components} components explain "
              f"{explained:.1f}% of variance\n")
        return X_train_proc, X_test_proc, scaler, pca

    print("🔧 Features scaled with StandardScaler (no PCA)\n")
    return X_train_scaled, X_test_scaled, scaler, None
