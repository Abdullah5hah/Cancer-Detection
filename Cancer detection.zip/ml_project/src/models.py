"""
models.py
---------
Define, train, and tune five classifiers:
  1. Logistic Regression
  2. Random Forest
  3. Support Vector Machine (SVM)
  4. K-Nearest Neighbors (KNN)
  5. XGBoost

Returns a dict of fitted models plus the best one after grid search.
"""

import time
import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
from sklearn.neighbors import KNeighborsClassifier
from sklearn.model_selection import cross_val_score, GridSearchCV

try:
    from xgboost import XGBClassifier
    XGBOOST_AVAILABLE = True
except ImportError:
    XGBOOST_AVAILABLE = False
    print("⚠️  XGBoost not found — skipping that model. "
          "Install with: pip install xgboost")


# ── Base models ──────────────────────────────────────────────────────────────

def get_base_models() -> dict:
    models = {
        "Logistic Regression": LogisticRegression(max_iter=1000, random_state=42),
        "Random Forest":       RandomForestClassifier(n_estimators=100, random_state=42),
        "SVM":                 SVC(probability=True, random_state=42),
        "KNN":                 KNeighborsClassifier(n_neighbors=5),
    }
    if XGBOOST_AVAILABLE:
        models["XGBoost"] = XGBClassifier(
            n_estimators=100, use_label_encoder=False,
            eval_metric="logloss", random_state=42, verbosity=0
        )
    return models


# ── Train & cross-validate ───────────────────────────────────────────────────

def train_all(X_train, y_train, cv: int = 5) -> dict:
    """
    Fit every model and report 5-fold cross-validation accuracy.
    Returns a dict {name: fitted_model}.
    """
    models = get_base_models()
    fitted  = {}
    results = []

    print("🤖 Training models...\n")
    print(f"   {'Model':<22} {'CV Accuracy':>12}  {'Std':>7}  {'Time':>7}")
    print("   " + "─" * 54)

    for name, model in models.items():
        t0 = time.time()
        scores = cross_val_score(model, X_train, y_train,
                                 cv=cv, scoring="accuracy", n_jobs=-1)
        model.fit(X_train, y_train)
        elapsed = time.time() - t0

        results.append((name, scores.mean(), scores.std()))
        fitted[name] = model
        print(f"   {name:<22} {scores.mean():.4f}       ±{scores.std():.4f}  {elapsed:>5.1f}s")

    best_name = max(results, key=lambda x: x[1])[0]
    print(f"\n   🏆 Best cross-val model: {best_name}\n")
    return fitted


# ── Hyperparameter tuning ────────────────────────────────────────────────────

PARAM_GRIDS = {
    "Logistic Regression": {
        "C":          [0.01, 0.1, 1, 10, 100],
        "l1_ratio":   [0.0, 1.0],   # 0.0 ≡ L2, 1.0 ≡ L1
        "solver":     ["saga"],
    },
    "Random Forest": {
        "n_estimators": [50, 100, 200],
        "max_depth":    [None, 5, 10],
        "min_samples_split": [2, 5],
    },
    "SVM": {
        "C":      [0.1, 1, 10],
        "kernel": ["rbf", "linear"],
        "gamma":  ["scale", "auto"],
    },
    "KNN": {
        "n_neighbors": [3, 5, 7, 9, 11],
        "weights":     ["uniform", "distance"],
        "metric":      ["euclidean", "manhattan"],
    },
}
if XGBOOST_AVAILABLE:
    PARAM_GRIDS["XGBoost"] = {
        "n_estimators": [50, 100],
        "max_depth":    [3, 5, 7],
        "learning_rate": [0.05, 0.1, 0.2],
    }


def tune_best_model(fitted_models: dict, X_train, y_train,
                    cv: int = 5) -> tuple:
    """
    Run GridSearchCV on every model that has a param grid.
    Returns (best_model_name, best_estimator, best_params, best_score).
    """
    print("🔍 Hyperparameter tuning with GridSearchCV...\n")

    overall_best = {"score": 0}

    for name, model in fitted_models.items():
        if name not in PARAM_GRIDS:
            continue

        grid = GridSearchCV(
            model, PARAM_GRIDS[name],
            cv=cv, scoring="accuracy", n_jobs=-1, refit=True
        )
        grid.fit(X_train, y_train)

        print(f"   {name}")
        print(f"     Best params : {grid.best_params_}")
        print(f"     Best CV acc : {grid.best_score_:.4f}\n")

        if grid.best_score_ > overall_best["score"]:
            overall_best = {
                "score":  grid.best_score_,
                "name":   name,
                "model":  grid.best_estimator_,
                "params": grid.best_params_,
            }

    print(f"   🏆 Tuned best model  : {overall_best['name']}")
    print(f"      Tuned best score  : {overall_best['score']:.4f}\n")

    return (overall_best["name"], overall_best["model"],
            overall_best["params"], overall_best["score"])
