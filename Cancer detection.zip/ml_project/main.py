"""
main.py
=======
End-to-end ML pipeline for Breast Cancer Detection.

Steps
-----
1. Load data
2. Exploratory Data Analysis  → outputs/1_*.png … 4_*.png
3. Preprocessing (scaling)
4. Train 5 models with cross-validation
5. Hyperparameter tuning (GridSearchCV)
6. Evaluate best model        → outputs/5_*.png … 8_*.png
7. Save best model            → outputs/best_model.pkl

Run
---
    python main.py
"""

import os
import sys
import joblib

# Make sure the src/ package is importable from anywhere
sys.path.insert(0, os.path.dirname(__file__))

from src.data_loader   import load_data
from src.eda           import run_eda
from src.preprocessing import preprocess
from src.models        import train_all, tune_best_model
from src.evaluation    import (
    print_report,
    plot_confusion_matrix,
    plot_roc_curves,
    plot_pr_curves,
    plot_feature_importance,
)

OUTPUT_DIR = os.path.join(os.path.dirname(__file__), "outputs")


def main():
    print("\n" + "=" * 60)
    print("  🧠  ML Cancer Detection Pipeline")
    print("=" * 60 + "\n")

    # ── 1. Load data ─────────────────────────────────────────────
    X_train, X_test, y_train, y_test, feature_names, df = load_data()

    # ── 2. EDA ───────────────────────────────────────────────────
    run_eda(df, output_dir=OUTPUT_DIR)

    # ── 3. Preprocessing ─────────────────────────────────────────
    X_train_s, X_test_s, scaler, _ = preprocess(X_train, X_test, use_pca=False)

    # ── 4. Train all models ───────────────────────────────────────
    fitted_models = train_all(X_train_s, y_train)

    # ── 5. Hyperparameter tuning ──────────────────────────────────
    best_name, best_model, best_params, best_cv_score = tune_best_model(
        fitted_models, X_train_s, y_train
    )
    # Replace the base model with the tuned version
    fitted_models[best_name] = best_model

    # ── 6. Evaluation ─────────────────────────────────────────────
    print("📈 Evaluating all models on test set...\n")
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    print_report(best_model, X_test_s, y_test, model_name=best_name)

    plot_confusion_matrix(best_model, X_test_s, y_test,
                          model_name=best_name, output_dir=OUTPUT_DIR)
    plot_roc_curves(fitted_models, X_test_s, y_test, output_dir=OUTPUT_DIR)
    plot_pr_curves(fitted_models, X_test_s, y_test,  output_dir=OUTPUT_DIR)
    plot_feature_importance(fitted_models, feature_names,  output_dir=OUTPUT_DIR)

    # ── 7. Save best model ────────────────────────────────────────
    model_path = os.path.join(OUTPUT_DIR, "best_model.pkl")
    joblib.dump({"model": best_model, "scaler": scaler,
                 "name": best_name, "params": best_params}, model_path)
    print(f"\n💾 Best model saved → {model_path}")

    print("\n" + "=" * 60)
    print(f"  ✅  Done!  All outputs are in '{OUTPUT_DIR}/'")
    print("=" * 60 + "\n")


if __name__ == "__main__":
    main()
